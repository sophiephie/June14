package Activity4;

import java.util.Scanner;

public class Question15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Input a grade : ");
		char gra = sc.next();
		
		gra = 0; 
		String graddes;
		
		switch (gra) {
		case 'E':
		graddes = "Excellent";
		break;
		}

	}

	private static char nextChar() {
		// TODO Auto-generated method stub
		return 0;
	}

}
