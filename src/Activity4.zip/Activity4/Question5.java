package Activity4;

import java.util.Scanner;

public class Question5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Input 3 variables");
		int a = sc.nextInt(); // variable 1
		int b = sc.nextInt();// variable 2
		int c = sc.nextInt();// variable 3
	}

}
